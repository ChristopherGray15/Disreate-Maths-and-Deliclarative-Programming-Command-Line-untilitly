class Person:
	
	def __init__(self,name, phone_no):
		self.name = name
		self.phone_no = phone_no
	
	def setName(self, name):
		self.name = name
	
	def getName(self):
		return self.name
	
	def setPhoneNo(self, phone_no):
		self.phone_no = phone_no
	
	def getPhoneNo(self):
		return self.phone_no
	
        
