#Christopher Gray
#17117107
#chris Gray 17117107 lab 01 .py

#lab 01 python operation

#section 3.1 add and subtracting
print("section 3.1 add and subtracting")
print(2+2)
print("==========================")


#section 3.1 add and subtracting
print("section 3.1 add and subtracting")

print("==========================")

print (7+5/2)

print (5+7.0/2)

print (11%5+1*3)

print (11%(5+1)*3)

print (3--8)

print (1% 3)

print (0%3)

print (3%2.5)

a=2
b=2
c=3
d=4
print(b*b+4*a*c)

x=b*b+4*a*c
print(x**(1/2))

